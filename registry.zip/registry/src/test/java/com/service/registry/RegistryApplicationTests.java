package com.service.registry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
